package com.amrit.task_reminder

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
